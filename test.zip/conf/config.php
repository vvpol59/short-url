<?php
/**
 * Конфигуратор
 * User: vvpol
 * Date: 21.03.2017
 * Time: 7:23
 */
$config = [
    'table' => 'tst_urls',  // имя таблицы
    'dsn' => 'mysql:host=localhost;dbname=test',
    'user' => 'root',
    'password' => ''
];


